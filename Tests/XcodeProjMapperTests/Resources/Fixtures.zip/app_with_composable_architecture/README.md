# Application with the Composable Architecture (TCA)

This example contains an example that uses the Composable Architecture.
