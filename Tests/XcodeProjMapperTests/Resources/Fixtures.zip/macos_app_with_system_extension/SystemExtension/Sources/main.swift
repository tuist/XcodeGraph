import Foundation

print("System Extension")
