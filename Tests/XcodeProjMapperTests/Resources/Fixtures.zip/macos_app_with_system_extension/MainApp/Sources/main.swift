import AppKit

_ = NSApplicationMain(CommandLine.argc, CommandLine.unsafeArgv)
