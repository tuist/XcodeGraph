public final class LocalSwiftPackage {
    public init() {}
}
