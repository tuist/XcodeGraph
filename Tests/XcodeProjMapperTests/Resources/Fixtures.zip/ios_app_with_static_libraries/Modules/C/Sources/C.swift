import Foundation

public enum C {
    public static let value: String = "cValue"

    public static func printFromC() {
        print("print from C")
    }
}
