import Foundation

public enum B {
    public static let value: String = "bValue"

    public static func printFromB() {
        print("print from B")
    }
}
