import ProjectDescription

let workspace = Workspace(
    name: "Workspace",
    projects: ["App", "Framework1", "Framework2"]
)
