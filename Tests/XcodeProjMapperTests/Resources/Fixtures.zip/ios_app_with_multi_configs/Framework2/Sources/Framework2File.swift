import Foundation

public class Framework2File {
    public init() {}

    public func hello() -> String {
        "Framework2File.hello()"
    }
}
