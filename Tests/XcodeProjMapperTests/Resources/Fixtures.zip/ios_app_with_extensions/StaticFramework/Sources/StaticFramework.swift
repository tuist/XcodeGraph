import Foundation

public struct StaticFramework {
    public init() {}
}
