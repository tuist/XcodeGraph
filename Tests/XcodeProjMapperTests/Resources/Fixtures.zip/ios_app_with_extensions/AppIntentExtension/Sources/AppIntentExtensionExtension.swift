import AppIntents

@main
struct AppIntentExtensionExtension: AppIntentsExtension {
    // No implementation
}
