import Foundation

public struct DynamicFramework {
    public init() {}
}
