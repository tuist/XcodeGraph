import DynamicFramework
import Foundation

let dynamicClass = DynamicFramework()
