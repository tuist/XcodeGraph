import ProjectDescription

let workspace = Workspace(
    name: "Workspace",
    projects: ["App", "Framework1", "StaticFramework1"]
)
