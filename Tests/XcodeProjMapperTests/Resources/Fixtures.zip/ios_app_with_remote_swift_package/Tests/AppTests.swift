import Foundation
import XCTest

@testable import App

final class AppTests: XCTestCase {}
