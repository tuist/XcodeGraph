# iOS App with a remote Swift package

An iOS application with a remote Swift package.