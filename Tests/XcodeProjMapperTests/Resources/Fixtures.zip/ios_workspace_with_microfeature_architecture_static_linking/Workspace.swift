import ProjectDescription

let workspace = Workspace(
    name: "Workspace",
    projects: [
        "StaticApp",
        "Frameworks/**",
    ]
)
