import Core
import Foundation

public class DataClass {
    let core = CoreClass()

    public init() {}
}
