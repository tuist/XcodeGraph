import Foundation
import XCTest

@testable import Data

final class DataClassTests: XCTestCase {}
