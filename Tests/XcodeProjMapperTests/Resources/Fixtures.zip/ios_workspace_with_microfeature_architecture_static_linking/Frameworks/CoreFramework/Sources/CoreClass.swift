import Foundation

public class CoreClass {
    public init() {}
}
