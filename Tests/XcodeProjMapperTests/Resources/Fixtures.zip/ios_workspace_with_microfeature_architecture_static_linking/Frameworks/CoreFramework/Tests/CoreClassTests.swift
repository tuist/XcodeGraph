import Foundation
import XCTest

@testable import Core

final class CoreClassTests: XCTestCase {}
