import Data
import Foundation
import UIKit

class UIComponentA: UIView {
    let data = DataClass()
}
