import Foundation
import XCTest

@testable import UIComponents

final class UIComponentATests: XCTestCase {}
