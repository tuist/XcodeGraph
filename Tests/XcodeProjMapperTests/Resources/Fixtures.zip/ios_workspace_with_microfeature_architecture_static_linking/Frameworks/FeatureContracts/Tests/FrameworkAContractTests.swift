import Foundation
import XCTest

@testable import FrameworkA

final class FrameworkAContractTests: XCTestCase {}
