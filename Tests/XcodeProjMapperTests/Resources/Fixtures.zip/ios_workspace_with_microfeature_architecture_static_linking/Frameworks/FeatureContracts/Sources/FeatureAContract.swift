import Foundation

public protocol FeatureAContract {
    func run()
}
