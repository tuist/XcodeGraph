import Foundation
import XCTest

@testable import StaticApp

final class StaticAppTests: XCTestCase {}
