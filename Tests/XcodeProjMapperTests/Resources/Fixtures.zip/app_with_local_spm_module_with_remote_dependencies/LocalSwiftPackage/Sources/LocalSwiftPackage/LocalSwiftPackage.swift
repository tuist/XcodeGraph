import Collections

public final class LocalSwiftPackage {
    public init() {}
    public var deque: Deque<String> = []
}
