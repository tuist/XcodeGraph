import TuistSupport

let logger = Logger(label: "io.tuist.plugin")
