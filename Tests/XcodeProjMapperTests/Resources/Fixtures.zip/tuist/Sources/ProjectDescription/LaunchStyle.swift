import Foundation

public enum LaunchStyle: Codable, Sendable {
    case automatically
    case waitForExecutableToBeLaunched
}
