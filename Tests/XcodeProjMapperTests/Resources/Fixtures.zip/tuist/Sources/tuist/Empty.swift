// This empty file is needed in order to compile `@main` attribute with swift-tools-version:5.4.0
